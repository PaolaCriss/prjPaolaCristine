package com.prjPaolaCristine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrjPaolaCristineApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrjPaolaCristineApplication.class, args);
	}

}
