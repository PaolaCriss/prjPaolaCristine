package com.prjPaolaCristine.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjPaolaCristine.entities.ItemPedido;

public interface ItemPedidoRepositories extends JpaRepository<ItemPedido, Long> {

}
