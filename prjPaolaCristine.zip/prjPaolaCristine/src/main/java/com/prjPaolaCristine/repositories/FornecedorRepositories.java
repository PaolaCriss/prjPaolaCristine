package com.prjPaolaCristine.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjPaolaCristine.entities.Fornecedor;

public interface FornecedorRepositories extends JpaRepository<Fornecedor, Long> {

}
