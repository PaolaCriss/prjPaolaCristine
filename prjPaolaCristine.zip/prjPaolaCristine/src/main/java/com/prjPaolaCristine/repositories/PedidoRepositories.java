package com.prjPaolaCristine.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjPaolaCristine.entities.Pedido;

public interface PedidoRepositories extends JpaRepository<Pedido, Long> {

}
