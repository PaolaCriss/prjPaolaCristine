package com.prjPaolaCristine.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prjPaolaCristine.entities.Produto;

public interface ProdutoRepositories extends JpaRepository<Produto, Long>{

}
