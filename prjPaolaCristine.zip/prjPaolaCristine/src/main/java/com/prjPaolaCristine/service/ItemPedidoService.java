package com.prjPaolaCristine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjPaolaCristine.entities.ItemPedido;
import com.prjPaolaCristine.repositories.ItemPedidoRepositories;

@Service
public class ItemPedidoService {

	@Autowired
	private ItemPedidoRepositories itemPedidoRepositories;

	public List<ItemPedido> getAllItemPedido() {
		return itemPedidoRepositories.findAll();
	}

	public ItemPedido getItemPedidoById(long id_itempedido) {
		return itemPedidoRepositories.findById(id_itempedido).orElse(null);
	}

	public ItemPedido saveItemPedido(ItemPedido itemPedido) {
		return itemPedidoRepositories.save(itemPedido);
	}
}
