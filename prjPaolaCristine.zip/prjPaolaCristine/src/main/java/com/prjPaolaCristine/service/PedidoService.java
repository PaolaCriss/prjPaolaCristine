package com.prjPaolaCristine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.prjPaolaCristine.entities.Pedido;
import com.prjPaolaCristine.repositories.PedidoRepositories;

@Service
public class PedidoService {

	@Autowired
	private PedidoRepositories pedidoRepositories;

	public List<Pedido> getAllPedido() {
		return pedidoRepositories.findAll();
	}

	public Pedido getPedidoById(long id_pedido) {
		return pedidoRepositories.findById(id_pedido).orElse(null);
	}

	public Pedido savePedido(Pedido pedido) {
		return pedidoRepositories.save(pedido);
	}
}
