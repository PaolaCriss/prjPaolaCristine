package com.prjPaolaCristine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjPaolaCristine.entities.Produto;
import com.prjPaolaCristine.repositories.ProdutoRepositories;

@Service
public class ProdutoService {

	@Autowired
	private ProdutoRepositories produtoRepositories;

	public List<Produto> getAllProduto() {
		return produtoRepositories.findAll();
	}

	public Produto getProdutoById(long id_produto) {
		return produtoRepositories.findById(id_produto).orElse(null);
	}

	public Produto saveProduto(Produto produto) {
		return produtoRepositories.save(produto);
	}
}
