package com.prjPaolaCristine.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prjPaolaCristine.entities.Fornecedor;
import com.prjPaolaCristine.repositories.FornecedorRepositories;

@Service
public class FornecedorService {
	
		@Autowired
		private FornecedorRepositories fornecedorRepositories;

		public List<Fornecedor> getAllFornecedor() {
			return fornecedorRepositories.findAll();
		}

		public Fornecedor getFornecedorById(long id_fonecedor) {
			return fornecedorRepositories.findById(id_fonecedor).orElse(null);
		}

		public Fornecedor saveFornecedor(Fornecedor fornecedor) {
			return fornecedorRepositories.save(fornecedor);
		}
}

