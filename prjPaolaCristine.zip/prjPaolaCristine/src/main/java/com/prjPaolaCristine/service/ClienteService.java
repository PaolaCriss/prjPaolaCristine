package com.prjPaolaCristine.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.prjPaolaCristine.entities.Cliente;
import com.prjPaolaCristine.repositories.ClienteRepositories;

@Service
public class ClienteService {

	@Autowired
	private ClienteRepositories clienteRepositories;

	public List<Cliente> getAllCliente() {
		return clienteRepositories.findAll();
	}

	public Cliente getClienteById(long id_cliente) {
		return clienteRepositories.findById(id_cliente).orElse(null);
	}

	public Cliente saveCliente(Cliente cliente) {
		return clienteRepositories.save(cliente);
	}
}
