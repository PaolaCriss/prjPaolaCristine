package com.prjPaolaCristine.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Table (name = "Fornecedor")
@Entity
public class Fornecedor {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY) 
	@Column(name = "id_fornecedor", nullable = false)
	private Long id_fornecedor;
	
	@Column(name = "cnpj", nullable = false, length = 100)
	private String cnpj;
	
	@Column(name = "Email", nullable = false, length = 100)
	private String email;
	
	@Column(name = "nome", nullable = false, length = 100)
	private String nome;
	
	@Column(name = "telefone", nullable = false, length = 100)
	private int telefone;
	
}
