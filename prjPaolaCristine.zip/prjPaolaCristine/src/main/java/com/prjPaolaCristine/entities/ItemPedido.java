package com.prjPaolaCristine.entities;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table (name = "ItemPedido")
public class ItemPedido {

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY) 
	@Column(name = "id_itempedido", nullable = false)
	private Long id_itempedido;
	
	@Column(name = "quantidade", nullable = false, length = 100)
	private Integer quantidade;
	
	@Column(name = "valor_unitario", nullable = false, length = 100)
	private BigDecimal valor_unitario;
		
	@ManyToOne(fetch = FetchType.LAZY) 
	@JoinColumn (name = "id_pedido", nullable = false) 
	private Pedido id_pedido;
	
	@ManyToOne(fetch = FetchType.LAZY) 
	@JoinColumn (name = "id_produto", nullable = false) 
	private Produto id_produto;
	
}
