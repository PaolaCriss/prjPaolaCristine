package com.prjPaolaCristine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrjPaolaCristineApplicationTests {

	@Test
	void contextLoads() {
	}

}
